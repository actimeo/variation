--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: meta; Type: SCHEMA; Schema: -; Owner: variation
--

CREATE SCHEMA meta;


ALTER SCHEMA meta OWNER TO variation;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


SET search_path = public, pg_catalog;

--
-- Name: pgprocedures_search_arguments; Type: TYPE; Schema: public; Owner: variation
--

CREATE TYPE pgprocedures_search_arguments AS (
	argnames character varying[],
	argtypes oidvector
);


ALTER TYPE public.pgprocedures_search_arguments OWNER TO variation;

--
-- Name: pgprocedures_search_function; Type: TYPE; Schema: public; Owner: variation
--

CREATE TYPE pgprocedures_search_function AS (
	proc_nspname name,
	proargtypes oidvector,
	prorettype oid,
	ret_typtype character(1),
	ret_typname name,
	ret_nspname name,
	proretset boolean
);


ALTER TYPE public.pgprocedures_search_function OWNER TO variation;

SET search_path = meta, pg_catalog;

--
-- Name: meta_dirinfo_add(integer, character varying); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_dirinfo_add(prm_din_id_parent integer, prm_libelle character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	ret integer;
BEGIN
	INSERT INTO meta.dirinfo (din_id_parent, din_libelle) VALUES (prm_din_id_parent, prm_libelle)
		RETURNING din_id INTO ret;
	RETURN ret;
END;
$$;


ALTER FUNCTION meta.meta_dirinfo_add(prm_din_id_parent integer, prm_libelle character varying) OWNER TO variation;

--
-- Name: meta_dirinfo_delete(integer); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_dirinfo_delete(prm_din_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
	DELETE FROM meta.dirinfo WHERE din_id = prm_din_id;
END;
$$;


ALTER FUNCTION meta.meta_dirinfo_delete(prm_din_id integer) OWNER TO variation;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: dirinfo; Type: TABLE; Schema: meta; Owner: variation; Tablespace: 
--

CREATE TABLE dirinfo (
    din_id integer NOT NULL,
    din_id_parent integer,
    din_libelle character varying
);


ALTER TABLE meta.dirinfo OWNER TO variation;

--
-- Name: meta_dirinfo_list(integer); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_dirinfo_list(prm_din_id_parent integer) RETURNS SETOF dirinfo
    LANGUAGE plpgsql
    AS $$
DECLARE
	row meta.dirinfo;
BEGIN
	FOR row IN
		SELECT * FROM meta.dirinfo WHERE (prm_din_id_parent ISNULL AND din_id_parent ISNULL) OR (din_id_parent = prm_din_id_parent)
	LOOP
		RETURN NEXT row;
	END LOOP;
END;
$$;


ALTER FUNCTION meta.meta_dirinfo_list(prm_din_id_parent integer) OWNER TO variation;

--
-- Name: meta_dirinfo_move(integer, integer); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_dirinfo_move(prm_din_id integer, prm_din_id_parent integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
	UPDATE meta.dirinfo SET din_id_parent = prm_din_id_parent WHERE din_id = prm_din_id;
END;
$$;


ALTER FUNCTION meta.meta_dirinfo_move(prm_din_id integer, prm_din_id_parent integer) OWNER TO variation;

--
-- Name: meta_dirinfo_nouveaux(integer); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_dirinfo_nouveaux(prm_din_id integer) RETURNS SETOF dirinfo
    LANGUAGE plpgsql
    AS $$
DECLARE
	row meta.dirinfo;
BEGIN
	FOR row IN
		SELECT * FROM meta.dirinfo WHERE din_id > prm_din_id ORDER BY din_id 
	LOOP
		RETURN NEXT row;
	END LOOP;
END;
$$;


ALTER FUNCTION meta.meta_dirinfo_nouveaux(prm_din_id integer) OWNER TO variation;

--
-- Name: meta_dirinfo_update(integer, character varying); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_dirinfo_update(prm_din_id integer, prm_libelle character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
	UPDATE meta.dirinfo SET din_libelle = prm_libelle WHERE din_id = prm_din_id;
END;
$$;


ALTER FUNCTION meta.meta_dirinfo_update(prm_din_id integer, prm_libelle character varying) OWNER TO variation;

--
-- Name: entite; Type: TABLE; Schema: meta; Owner: variation; Tablespace: 
--

CREATE TABLE entite (
    ent_id integer NOT NULL,
    ent_code character varying,
    ent_libelle character varying
);


ALTER TABLE meta.entite OWNER TO variation;

--
-- Name: TABLE entite; Type: COMMENT; Schema: meta; Owner: variation
--

COMMENT ON TABLE entite IS 'Type de personne';


--
-- Name: meta_entite_liste(); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_entite_liste() RETURNS SETOF entite
    LANGUAGE plpgsql
    AS $$
DECLARE
	row RECORD;
BEGIN
	FOR row IN
		SELECT * FROM meta.entite ORDER BY ent_id
	LOOP
		RETURN NEXT row;
	END LOOP;
END;
$$;


ALTER FUNCTION meta.meta_entite_liste() OWNER TO variation;

--
-- Name: meta_info_add(integer, character varying, character varying, character varying, boolean, boolean, boolean); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_info_add(prm_int_id integer, prm_code character varying, prm_libelle character varying, prm_libelle_complet character varying, prm_etendu boolean, prm_historique boolean, prm_multiple boolean) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	ret integer;
BEGIN
	INSERT INTO meta.info(int_id, inf_code, inf_libelle, inf_libelle_complet, inf_etendu, inf_historique, inf_multiple) VALUES (prm_int_id, prm_code, prm_libelle, prm_libelle_complet, prm_etendu, prm_historique, prm_multiple) RETURNING inf_id INTO ret;
	RETURN ret;
END;
$$;


ALTER FUNCTION meta.meta_info_add(prm_int_id integer, prm_code character varying, prm_libelle character varying, prm_libelle_complet character varying, prm_etendu boolean, prm_historique boolean, prm_multiple boolean) OWNER TO variation;

--
-- Name: meta_info_aide_get(integer); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_info_aide_get(prm_inf_id integer) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
	ret text;
BEGIN
	SELECT ina_aide INTO ret FROM meta.info_aide WHERE inf_id = prm_inf_id;
	RETURN ret;
END;
$$;


ALTER FUNCTION meta.meta_info_aide_get(prm_inf_id integer) OWNER TO variation;

--
-- Name: meta_info_aide_set(integer, text); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_info_aide_set(prm_inf_id integer, prm_aide text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
	IF prm_aide ISNULL THEN
		DELETE FROM meta.info_aide WHERE inf_id = prm_inf_id;
	ELSE
		UPDATE meta.info_aide SET ina_aide = prm_aide WHERE inf_id = prm_inf_id;
		IF NOT FOUND THEN
			INSERT INTO meta.info_aide (inf_id, ina_aide) VALUES (prm_inf_id, prm_aide);
		END IF;
	END IF;
END;
$$;


ALTER FUNCTION meta.meta_info_aide_set(prm_inf_id integer, prm_aide text) OWNER TO variation;

--
-- Name: info; Type: TABLE; Schema: meta; Owner: variation; Tablespace: 
--

CREATE TABLE info (
    inf_id integer NOT NULL,
    int_id integer,
    inf_code character varying,
    inf_libelle character varying,
    inf__textelong_nblignes integer,
    inf__selection_code integer,
    inf_etendu boolean DEFAULT false NOT NULL,
    inf_historique boolean DEFAULT false NOT NULL,
    inf_multiple boolean DEFAULT false NOT NULL,
    inf__groupe_type character varying,
    inf__contact_filtre character varying,
    inf__metier_secteur character varying,
    inf__contact_secteur character varying,
    inf__etablissement_interne boolean,
    din_id integer,
    inf__groupe_soustype integer,
    inf_libelle_complet character varying,
    inf__date_echeance boolean,
    inf__date_echeance_icone character varying,
    inf__date_echeance_secteur character varying,
    inf__etablissement_secteur character varying
);


ALTER TABLE meta.info OWNER TO variation;

--
-- Name: TABLE info; Type: COMMENT; Schema: meta; Owner: variation
--

COMMENT ON TABLE info IS 'Champ d''édition d''une personne';


--
-- Name: meta_info_get(integer); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_info_get(prm_inf_id integer) RETURNS info
    LANGUAGE plpgsql
    AS $$
DECLARE
	ret meta.info;
BEGIN
	SELECT * INTO ret FROM meta.info WHERE inf_id = prm_inf_id;
	RETURN ret;
END;
$$;


ALTER FUNCTION meta.meta_info_get(prm_inf_id integer) OWNER TO variation;

--
-- Name: meta_info_liste(); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_info_liste() RETURNS SETOF info
    LANGUAGE plpgsql
    AS $$
DECLARE
	row meta.info;
BEGIN
	FOR row IN
		SELECT * FROM meta.info ORDER BY inf_libelle
	LOOP
		RETURN NEXT row;
	END LOOP;
END;
$$;


ALTER FUNCTION meta.meta_info_liste() OWNER TO variation;

--
-- Name: meta_info_liste(character varying); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_info_liste(str character varying) RETURNS SETOF info
    LANGUAGE plpgsql
    AS $$
DECLARE
	row meta.info;
BEGIN
	FOR row IN
		SELECT * FROM meta.info WHERE str ISNULL OR inf_code ilike '%'||str||'%' OR inf_libelle ilike '%'||str||'%' ORDER BY inf_libelle
	LOOP
		RETURN NEXT row;
	END LOOP;
END;
$$;


ALTER FUNCTION meta.meta_info_liste(str character varying) OWNER TO variation;

--
-- Name: meta_info_move(integer, integer); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_info_move(prm_inf_id integer, prm_din_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
	UPDATE meta.info SET din_id = prm_din_id WHERE inf_id = prm_inf_id;
END;
$$;


ALTER FUNCTION meta.meta_info_move(prm_inf_id integer, prm_din_id integer) OWNER TO variation;

--
-- Name: meta_info_nouveaux(integer); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_info_nouveaux(prm_inf_id integer) RETURNS SETOF info
    LANGUAGE plpgsql
    AS $$
DECLARE
	row meta.info;
BEGIN
	FOR row IN
		SELECT * FROM meta.info WHERE inf_id > prm_inf_id ORDER BY inf_id
	LOOP
		RETURN NEXT row;
	END LOOP;
END;
$$;


ALTER FUNCTION meta.meta_info_nouveaux(prm_inf_id integer) OWNER TO variation;

--
-- Name: meta_info_update(integer, integer, character varying, character varying, character varying, boolean, boolean, boolean); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_info_update(prm_inf_id integer, prm_int_id integer, prm_code character varying, prm_libelle character varying, prm_libelle_complet character varying, prm_etendu boolean, prm_historique boolean, prm_multiple boolean) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
	UPDATE meta.info SET 
		int_id = prm_int_id,
		inf_code = prm_code, 
		inf_libelle = prm_libelle, 
		inf_libelle_complet = prm_libelle_complet, 
		inf_etendu = prm_etendu, 
		inf_historique = prm_historique, 
		inf_multiple = prm_multiple 
	WHERE inf_id = prm_inf_id;
END;
$$;


ALTER FUNCTION meta.meta_info_update(prm_inf_id integer, prm_int_id integer, prm_code character varying, prm_libelle character varying, prm_libelle_complet character varying, prm_etendu boolean, prm_historique boolean, prm_multiple boolean) OWNER TO variation;

--
-- Name: meta_infos_contact_update(integer, character varying, character varying); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_infos_contact_update(prm_inf_id integer, prm_filtre character varying, prm_secteur character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
	UPDATE meta.info SET 
		inf__contact_filtre = prm_filtre,
		inf__contact_secteur = prm_secteur
		WHERE inf_id = prm_inf_id;
END;
$$;


ALTER FUNCTION meta.meta_infos_contact_update(prm_inf_id integer, prm_filtre character varying, prm_secteur character varying) OWNER TO variation;

--
-- Name: meta_infos_date_update(integer, boolean, character varying, character varying); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_infos_date_update(prm_inf_id integer, prm__date_echeance boolean, prm__date_echeance_icone character varying, prm__date_echeance_secteur character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
	UPDATE meta.info SET 
		inf__date_echeance = prm__date_echeance,
		inf__date_echeance_icone = prm__date_echeance_icone,
		inf__date_echeance_secteur = prm__date_echeance_secteur
		WHERE inf_id = prm_inf_id;
END;
$$;


ALTER FUNCTION meta.meta_infos_date_update(prm_inf_id integer, prm__date_echeance boolean, prm__date_echeance_icone character varying, prm__date_echeance_secteur character varying) OWNER TO variation;

--
-- Name: meta_infos_etablissement_update(integer, boolean, character varying); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_infos_etablissement_update(prm_inf_id integer, prm_interne boolean, prm__etablissement_secteur character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
	UPDATE meta.info SET 
		inf__etablissement_interne = prm_interne,
		inf__etablissement_secteur = prm__etablissement_secteur
		WHERE inf_id = prm_inf_id;
END;
$$;


ALTER FUNCTION meta.meta_infos_etablissement_update(prm_inf_id integer, prm_interne boolean, prm__etablissement_secteur character varying) OWNER TO variation;

--
-- Name: meta_infos_groupe_update(integer, character varying, integer); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_infos_groupe_update(prm_inf_id integer, prm_type character varying, prm_soustype integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
	UPDATE meta.info SET 
		inf__groupe_type = prm_type,
		inf__groupe_soustype = prm_soustype
		WHERE inf_id = prm_inf_id;
END;
$$;


ALTER FUNCTION meta.meta_infos_groupe_update(prm_inf_id integer, prm_type character varying, prm_soustype integer) OWNER TO variation;

--
-- Name: meta_infos_metier_update(integer, character varying); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_infos_metier_update(prm_inf_id integer, prm_secteur character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
	UPDATE meta.info SET 
		inf__metier_secteur = prm_secteur
		WHERE inf_id = prm_inf_id;
END;
$$;


ALTER FUNCTION meta.meta_infos_metier_update(prm_inf_id integer, prm_secteur character varying) OWNER TO variation;

--
-- Name: meta_infos_selection_update(integer, integer); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_infos_selection_update(prm_inf_id integer, prm_code integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
	UPDATE meta.info SET 
		inf__selection_code = prm_code
		WHERE inf_id = prm_inf_id;
END;
$$;


ALTER FUNCTION meta.meta_infos_selection_update(prm_inf_id integer, prm_code integer) OWNER TO variation;

--
-- Name: meta_infos_textelong_update(integer, integer); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_infos_textelong_update(prm_inf_id integer, prm_nblignes integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
	UPDATE meta.info SET 
		inf__textelong_nblignes = prm_nblignes
		WHERE inf_id = prm_inf_id;
END;
$$;


ALTER FUNCTION meta.meta_infos_textelong_update(prm_inf_id integer, prm_nblignes integer) OWNER TO variation;

--
-- Name: infos_type; Type: TABLE; Schema: meta; Owner: variation; Tablespace: 
--

CREATE TABLE infos_type (
    int_id integer NOT NULL,
    int_code character varying,
    int_libelle character varying,
    int_multiple boolean,
    int_historique boolean
);


ALTER TABLE meta.infos_type OWNER TO variation;

--
-- Name: TABLE infos_type; Type: COMMENT; Schema: meta; Owner: variation
--

COMMENT ON TABLE infos_type IS 'Types de champs (édition des personnes) ';


--
-- Name: meta_infos_type_liste(); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_infos_type_liste() RETURNS SETOF infos_type
    LANGUAGE plpgsql
    AS $$
DECLARE
	row meta.infos_type%ROWTYPE;
BEGIN
	FOR row IN
		SELECT * FROM meta.infos_type 
	LOOP
		RETURN NEXT row;
	END LOOP;
END;
$$;


ALTER FUNCTION meta.meta_infos_type_liste() OWNER TO variation;

--
-- Name: secteur; Type: TABLE; Schema: meta; Owner: variation; Tablespace: 
--

CREATE TABLE secteur (
    sec_id integer NOT NULL,
    sec_code character varying,
    sec_nom character varying,
    sec_est_prise_en_charge boolean,
    sec_icone character varying
);


ALTER TABLE meta.secteur OWNER TO variation;

--
-- Name: TABLE secteur; Type: COMMENT; Schema: meta; Owner: variation
--

COMMENT ON TABLE secteur IS 'Liste des secteurs de métiers';


--
-- Name: meta_secteur_liste(); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_secteur_liste() RETURNS SETOF secteur
    LANGUAGE plpgsql
    AS $$
DECLARE
	row meta.secteur;
BEGIN
	FOR row IN
		SELECT * FROM meta.secteur ORDER BY sec_nom
	LOOP
		RETURN NEXT row;
	END LOOP;
END;
$$;


ALTER FUNCTION meta.meta_secteur_liste() OWNER TO variation;

--
-- Name: meta_selection_add(character varying, character varying, character varying); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_selection_add(prm_code character varying, prm_libelle character varying, prm_info character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	ret integer;
BEGIN
	INSERT INTO meta.selection (sel_code, sel_libelle, sel_info) VALUES (prm_code, prm_libelle, prm_info) 
		RETURNING sel_id INTO ret;
	RETURN ret;
END;
$$;


ALTER FUNCTION meta.meta_selection_add(prm_code character varying, prm_libelle character varying, prm_info character varying) OWNER TO variation;

--
-- Name: meta_selection_entree_add(integer, character varying, integer); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_selection_entree_add(prm_sel_id integer, prm_libelle character varying, prm_ordre integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	ret integer;
BEGIN
	INSERT INTO meta.selection_entree (sel_id, sen_libelle, sen_ordre) VALUES (prm_sel_id, prm_libelle, prm_ordre) 
		RETURNING sen_id INTO ret;
	RETURN ret;
END;
$$;


ALTER FUNCTION meta.meta_selection_entree_add(prm_sel_id integer, prm_libelle character varying, prm_ordre integer) OWNER TO variation;

--
-- Name: selection_entree; Type: TABLE; Schema: meta; Owner: variation; Tablespace: 
--

CREATE TABLE selection_entree (
    sen_id integer NOT NULL,
    sel_id integer,
    sen_libelle character varying,
    sen_ordre integer
);


ALTER TABLE meta.selection_entree OWNER TO variation;

--
-- Name: TABLE selection_entree; Type: COMMENT; Schema: meta; Owner: variation
--

COMMENT ON TABLE selection_entree IS 'Valeurs des listes de sélection';


--
-- Name: meta_selection_entree_liste(integer); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_selection_entree_liste(prm_sel_id integer) RETURNS SETOF selection_entree
    LANGUAGE plpgsql
    AS $$
DECLARE
	row meta.selection_entree%ROWTYPE;
BEGIN
	FOR row IN
		SELECT * FROM meta.selection_entree WHERE sel_id = prm_sel_id ORDER BY sen_ordre
	LOOP
		RETURN NEXT row;
	END LOOP;
END;
$$;


ALTER FUNCTION meta.meta_selection_entree_liste(prm_sel_id integer) OWNER TO variation;

--
-- Name: meta_selection_entree_liste_par_code(character varying); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_selection_entree_liste_par_code(prm_sel_code character varying) RETURNS SETOF selection_entree
    LANGUAGE plpgsql
    AS $$
DECLARE
	row meta.selection_entree%ROWTYPE;
BEGIN
	FOR row IN
		SELECT * FROM meta.selection_entree WHERE sel_id = (SELECT sel_id FROM meta.selection WHERE sel_code = prm_sel_code) ORDER BY sen_ordre
	LOOP
		RETURN NEXT row;
	END LOOP;
END;
$$;


ALTER FUNCTION meta.meta_selection_entree_liste_par_code(prm_sel_code character varying) OWNER TO variation;

--
-- Name: meta_selection_entree_set_ordre(integer, integer); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_selection_entree_set_ordre(prm_sen_id integer, prm_ordre integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
	ret integer;
BEGIN
	UPDATE meta.selection_entree SET sen_ordre = prm_ordre WHERE sen_id = prm_sen_id;
END;
$$;


ALTER FUNCTION meta.meta_selection_entree_set_ordre(prm_sen_id integer, prm_ordre integer) OWNER TO variation;

--
-- Name: meta_selection_entree_supprime(integer); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_selection_entree_supprime(prm_sen_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
	DELETE FROM meta.selection_entree WHERE sen_id = prm_sen_id;
END;
$$;


ALTER FUNCTION meta.meta_selection_entree_supprime(prm_sen_id integer) OWNER TO variation;

--
-- Name: selection; Type: TABLE; Schema: meta; Owner: variation; Tablespace: 
--

CREATE TABLE selection (
    sel_id integer NOT NULL,
    sel_code character varying,
    sel_libelle character varying,
    sel_info character varying
);


ALTER TABLE meta.selection OWNER TO variation;

--
-- Name: TABLE selection; Type: COMMENT; Schema: meta; Owner: variation
--

COMMENT ON TABLE selection IS 'Liste des sélection (pour les champs sélection d''édition des personnes)';


--
-- Name: meta_selection_infos(integer); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_selection_infos(prm_sel_id integer) RETURNS selection
    LANGUAGE plpgsql
    AS $$
DECLARE
	ret meta.selection%ROWTYPE;
BEGIN
	SELECT * INTO ret FROM meta.selection WHERE sel_id = prm_sel_id;
	RETURN ret;
END;
$$;


ALTER FUNCTION meta.meta_selection_infos(prm_sel_id integer) OWNER TO variation;

--
-- Name: meta_selection_liste(); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_selection_liste() RETURNS SETOF selection
    LANGUAGE plpgsql
    AS $$
DECLARE
	row meta.selection;
BEGIN
	FOR row IN
		SELECT * FROM meta.selection ORDER BY sel_libelle
	LOOP
		RETURN NEXT row;
	END LOOP;
END;
$$;


ALTER FUNCTION meta.meta_selection_liste() OWNER TO variation;

--
-- Name: meta_selection_nouveaux(integer); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_selection_nouveaux(prm_sel_id integer) RETURNS SETOF selection
    LANGUAGE plpgsql
    AS $$
DECLARE
	row meta.selection;
BEGIN
	FOR row IN
		SELECT * FROM meta.selection WHERE sel_id > prm_sel_id ORDER BY sel_id
	LOOP
		RETURN NEXT row;
	END LOOP;
END;
$$;


ALTER FUNCTION meta.meta_selection_nouveaux(prm_sel_id integer) OWNER TO variation;

--
-- Name: meta_selection_update(integer, character varying, character varying, character varying); Type: FUNCTION; Schema: meta; Owner: variation
--

CREATE FUNCTION meta_selection_update(prm_sel_id integer, prm_code character varying, prm_libelle character varying, prm_info character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
	UPDATE meta.selection SET 
		sel_code = prm_code, 
		sel_libelle = prm_libelle, 
		sel_info = prm_info
		WHERE sel_id = prm_sel_id; 
END;
$$;


ALTER FUNCTION meta.meta_selection_update(prm_sel_id integer, prm_code character varying, prm_libelle character varying, prm_info character varying) OWNER TO variation;

SET search_path = public, pg_catalog;

--
-- Name: pgprocedures_search_arguments(character varying); Type: FUNCTION; Schema: public; Owner: variation
--

CREATE FUNCTION pgprocedures_search_arguments(prm_function character varying) RETURNS SETOF pgprocedures_search_arguments
    LANGUAGE plpgsql
    AS $$                                                                                                                                
DECLARE                                                                                                                           
 row pgprocedures_search_arguments%ROWTYPE;                                                                                       
BEGIN                                                                                                                             
 FOR row IN                                                                                                                       
   SELECT proargnames, proargtypes                                                                                                
    FROM pg_proc                                                                                                                  
     WHERE proname = prm_function                                                                                                 
     ORDER BY pronargs DESC                                                                                                       
 LOOP                                                                                                                             
   RETURN NEXT row;                                                                                                               
 END LOOP;                                                                                                                        
END;                                                                                                                              
$$;


ALTER FUNCTION public.pgprocedures_search_arguments(prm_function character varying) OWNER TO variation;

--
-- Name: pgprocedures_search_function(character varying, integer); Type: FUNCTION; Schema: public; Owner: variation
--

CREATE FUNCTION pgprocedures_search_function(prm_method character varying, prm_nargs integer) RETURNS pgprocedures_search_function
    LANGUAGE plpgsql
    AS $$                                                                                                                            
DECLARE                                                                                                                           
      ret pgprocedures_search_function%ROWTYPE;                                                                                   
BEGIN            
	--PERFORM pgprocedures_add_call (prm_method, prm_nargs);
      SELECT                                                                                                                      
          pg_namespace_proc.nspname AS proc_nspname,                                                                              
          proargtypes,                                                                                                            
          prorettype,                                                                                                             
          pg_type_ret.typtype AS ret_typtype,                                                                                     
          pg_type_ret.typname AS ret_typname,                                                                                     
          pg_namespace_ret.nspname AS ret_nspname,                                                                                
          proretset                                                                                                               
      INTO ret                                                                                                                    
      FROM pg_proc                                                                                                                
          INNER JOIN pg_type pg_type_ret ON pg_type_ret.oid = pg_proc.prorettype                                                  
          INNER JOIN pg_namespace pg_namespace_ret ON pg_namespace_ret.oid = pg_type_ret.typnamespace                             
          INNER JOIN pg_namespace pg_namespace_proc ON pg_namespace_proc.oid = pg_proc.pronamespace                               
      WHERE proname = prm_method AND pronargs = prm_nargs;                                                                        
      RETURN ret;                                                                                                                 
END;                                                                                                                              
$$;


ALTER FUNCTION public.pgprocedures_search_function(prm_method character varying, prm_nargs integer) OWNER TO variation;

--
-- Name: pour_code(character varying); Type: FUNCTION; Schema: public; Owner: variation
--

CREATE FUNCTION pour_code(str character varying) RETURNS character varying
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE

BEGIN
	RETURN LOWER (TRANSLATE (str,' ÀÁÂÃÄÅàáâãäåÒÓÔÕÖØòóôõöøÈÉÊËèéêëÇçÌÍÎÏìíîïÙÚÛÜùúûüÿÑñ°«»#,()''+/.&"', 
                                     '_aaaaaaaaaaaaooooooooooooeeeeeeeecciiiiiiiiuuuuuuuuynn___d_________'));
END;
$$;


ALTER FUNCTION public.pour_code(str character varying) OWNER TO variation;

SET search_path = meta, pg_catalog;

--
-- Name: dirinfo_din_id_seq; Type: SEQUENCE; Schema: meta; Owner: variation
--

CREATE SEQUENCE dirinfo_din_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE meta.dirinfo_din_id_seq OWNER TO variation;

--
-- Name: dirinfo_din_id_seq; Type: SEQUENCE OWNED BY; Schema: meta; Owner: variation
--

ALTER SEQUENCE dirinfo_din_id_seq OWNED BY dirinfo.din_id;


--
-- Name: entite_ent_id_seq; Type: SEQUENCE; Schema: meta; Owner: variation
--

CREATE SEQUENCE entite_ent_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE meta.entite_ent_id_seq OWNER TO variation;

--
-- Name: entite_ent_id_seq; Type: SEQUENCE OWNED BY; Schema: meta; Owner: variation
--

ALTER SEQUENCE entite_ent_id_seq OWNED BY entite.ent_id;


--
-- Name: info_aide; Type: TABLE; Schema: meta; Owner: variation; Tablespace: 
--

CREATE TABLE info_aide (
    ina_id integer NOT NULL,
    inf_id integer,
    ina_aide text
);


ALTER TABLE meta.info_aide OWNER TO variation;

--
-- Name: info_aide_ina_id_seq; Type: SEQUENCE; Schema: meta; Owner: variation
--

CREATE SEQUENCE info_aide_ina_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE meta.info_aide_ina_id_seq OWNER TO variation;

--
-- Name: info_aide_ina_id_seq; Type: SEQUENCE OWNED BY; Schema: meta; Owner: variation
--

ALTER SEQUENCE info_aide_ina_id_seq OWNED BY info_aide.ina_id;


--
-- Name: info_inf_id_seq; Type: SEQUENCE; Schema: meta; Owner: variation
--

CREATE SEQUENCE info_inf_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE meta.info_inf_id_seq OWNER TO variation;

--
-- Name: info_inf_id_seq; Type: SEQUENCE OWNED BY; Schema: meta; Owner: variation
--

ALTER SEQUENCE info_inf_id_seq OWNED BY info.inf_id;


--
-- Name: infos_type_int_id_seq; Type: SEQUENCE; Schema: meta; Owner: variation
--

CREATE SEQUENCE infos_type_int_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE meta.infos_type_int_id_seq OWNER TO variation;

--
-- Name: infos_type_int_id_seq; Type: SEQUENCE OWNED BY; Schema: meta; Owner: variation
--

ALTER SEQUENCE infos_type_int_id_seq OWNED BY infos_type.int_id;


--
-- Name: secteur_sec_id_seq; Type: SEQUENCE; Schema: meta; Owner: variation
--

CREATE SEQUENCE secteur_sec_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE meta.secteur_sec_id_seq OWNER TO variation;

--
-- Name: secteur_sec_id_seq; Type: SEQUENCE OWNED BY; Schema: meta; Owner: variation
--

ALTER SEQUENCE secteur_sec_id_seq OWNED BY secteur.sec_id;

--
-- Name: selection_entree_sen_id_seq; Type: SEQUENCE; Schema: meta; Owner: variation
--

CREATE SEQUENCE selection_entree_sen_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE meta.selection_entree_sen_id_seq OWNER TO variation;

--
-- Name: selection_entree_sen_id_seq; Type: SEQUENCE OWNED BY; Schema: meta; Owner: variation
--

ALTER SEQUENCE selection_entree_sen_id_seq OWNED BY selection_entree.sen_id;


--
-- Name: selection_sel_id_seq; Type: SEQUENCE; Schema: meta; Owner: variation
--

CREATE SEQUENCE selection_sel_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE meta.selection_sel_id_seq OWNER TO variation;

--
-- Name: selection_sel_id_seq; Type: SEQUENCE OWNED BY; Schema: meta; Owner: variation
--

ALTER SEQUENCE selection_sel_id_seq OWNED BY selection.sel_id;


--
-- Name: din_id; Type: DEFAULT; Schema: meta; Owner: variation
--

ALTER TABLE ONLY dirinfo ALTER COLUMN din_id SET DEFAULT nextval('dirinfo_din_id_seq'::regclass);


--
-- Name: ent_id; Type: DEFAULT; Schema: meta; Owner: variation
--

ALTER TABLE ONLY entite ALTER COLUMN ent_id SET DEFAULT nextval('entite_ent_id_seq'::regclass);


--
-- Name: inf_id; Type: DEFAULT; Schema: meta; Owner: variation
--

ALTER TABLE ONLY info ALTER COLUMN inf_id SET DEFAULT nextval('info_inf_id_seq'::regclass);


--
-- Name: ina_id; Type: DEFAULT; Schema: meta; Owner: variation
--

ALTER TABLE ONLY info_aide ALTER COLUMN ina_id SET DEFAULT nextval('info_aide_ina_id_seq'::regclass);


--
-- Name: int_id; Type: DEFAULT; Schema: meta; Owner: variation
--

ALTER TABLE ONLY infos_type ALTER COLUMN int_id SET DEFAULT nextval('infos_type_int_id_seq'::regclass);


--
-- Name: sec_id; Type: DEFAULT; Schema: meta; Owner: variation
--

ALTER TABLE ONLY secteur ALTER COLUMN sec_id SET DEFAULT nextval('secteur_sec_id_seq'::regclass);


--
-- Name: sel_id; Type: DEFAULT; Schema: meta; Owner: variation
--

ALTER TABLE ONLY selection ALTER COLUMN sel_id SET DEFAULT nextval('selection_sel_id_seq'::regclass);


--
-- Name: sen_id; Type: DEFAULT; Schema: meta; Owner: variation
--

ALTER TABLE ONLY selection_entree ALTER COLUMN sen_id SET DEFAULT nextval('selection_entree_sen_id_seq'::regclass);


--
-- Data for Name: dirinfo; Type: TABLE DATA; Schema: meta; Owner: variation
--

COPY dirinfo (din_id, din_id_parent, din_libelle) FROM stdin;
2	\N	Dossier
3	\N	Obligatoires
4	2	Etat civil
7	2	Education
6	2	Suivi médical
9	2	Habitat et cadre de vie
10	2	Décision de prise en charge
11	\N	Poubelle
12	2	Restauration
14	2	Droits et aides
15	14	Handicap
16	14	Famille
17	14	Assurances
18	2	Pédagogie
13	2	Projet individuel, bilan et évaluation
5	2	Admission et prise en charge
19	5	Autorisations
20	5	Pièces
8	2	Entourage et famille
21	2	Membre du personnel
22	14	Droits de séjour
23	2	Contact
24	3	Personnel
25	3	Contact
\.


--
-- Name: dirinfo_din_id_seq; Type: SEQUENCE SET; Schema: meta; Owner: variation
--

SELECT pg_catalog.setval('dirinfo_din_id_seq', 25, true);


--
-- Data for Name: entite; Type: TABLE DATA; Schema: meta; Owner: variation
--

COPY entite (ent_id, ent_code, ent_libelle) FROM stdin;
1	usager	Usager
2	personnel	Personnel
3	contact	Contact
6	famille	Famille
\.


--
-- Name: entite_ent_id_seq; Type: SEQUENCE SET; Schema: meta; Owner: variation
--

SELECT pg_catalog.setval('entite_ent_id_seq', 6, true);


--
-- Data for Name: info; Type: TABLE DATA; Schema: meta; Owner: variation
--

COPY info (inf_id, int_id, inf_code, inf_libelle, inf__textelong_nblignes, inf__selection_code, inf_etendu, inf_historique, inf_multiple, inf__groupe_type, inf__contact_filtre, inf__metier_secteur, inf__contact_secteur, inf__etablissement_interne, din_id, inf__groupe_soustype, inf_libelle_complet, inf__date_echeance, inf__date_echeance_icone, inf__date_echeance_secteur, inf__etablissement_secteur) FROM stdin;
30	4	sans_sel	Sans sel	\N	\N	f	f	f	\N	\N	\N	\N	\N	12	\N	\N	\N	\N	\N	\N
7	5	problematique	Problématique	\N	1	f	f	f	\N	\N	\N	\N	\N	5	\N	\N	\N	\N	\N	\N
45	5	animal_de_compagnie	Animal de compagnie	\N	5	f	f	f	\N	\N	\N	\N	\N	8	\N	\N	\N	\N	\N	\N
8	1	numero_securite_sociale	Numéro de sécurité sociale	\N	\N	f	f	f	\N	\N	\N	\N	\N	6	\N	\N	\N	\N	\N	\N
9	9	caisse_affiliation	Caisse d'affiliation	\N	\N	f	f	f	\N	\N	\N	\N	f	6	\N	\N	\N	\N	\N	sante
10	3	traitements	Traitement(s) spécifique(s)	5	\N	f	f	f	\N	\N	\N	\N	\N	6	\N	\N	\N	\N	\N	\N
11	7	referent	Référent	\N	\N	f	f	f	\N	personnel	\N	education	\N	7	\N	\N	\N	\N	\N	\N
20	5	composition_de_famille	Composition de famille	\N	3	f	f	f	\N	\N	\N	\N	\N	8	\N	\N	\N	\N	\N	\N
14	7	intervenants_medicaux_externes	Intervenants médicaux externes	\N	\N	f	f	f	\N	contact	\N	sante	\N	6	\N	\N	\N	\N	\N	\N
18	6	groupe_logement	Groupe de logement collectif	\N	\N	f	f	f	hebergement	\N	\N	\N	\N	9	\N	\N	\N	\N	\N	\N
38	1	numero_allocataire_caf	N° allocataire CAF	\N	\N	f	f	f	\N	\N	\N	\N	\N	16	\N	\N	\N	\N	\N	\N
22	1	numero_dossier_decision	Numéro de dossier	\N	\N	f	f	f	\N	\N	\N	\N	\N	10	\N	\N	\N	\N	\N	\N
43	4	admission_piece1	Carnet de vaccinations	\N	\N	f	f	f	\N	\N	\N	\N	\N	20	\N	\N	\N	\N	\N	\N
42	4	droit_image	Droit à l'image	\N	\N	f	f	f	\N	\N	\N	\N	\N	19	\N	\N	\N	\N	\N	\N
27	7	contact_decision	Contact	\N	\N	f	f	f	\N	contact	\N	decideur	\N	10	\N	\N	\N	\N	\N	\N
50	2	autorisation_provisoire_de_travail	Autorisation Provisoire de Travail (APT)	\N	\N	f	f	f	\N	\N	\N	\N	\N	22	\N	\N	t	\N	\N	\N
21	6	decision	Décision de prise en charge	\N	\N	f	f	f	decideur	\N	\N	\N	\N	10	\N	\N	\N	\N	\N	\N
23	1	numero_dossier_prise_en_charge	Numéro de dossier	\N	\N	f	f	f	\N	\N	\N	\N	\N	5	\N	\N	\N	\N	\N	\N
26	1	nationalite_actuelle	Nationalité	\N	\N	f	f	f	\N	\N	\N	\N	\N	4	\N	\N	\N	\N	\N	\N
4	1	lieu_de_naissance	Lieu de naissance	\N	\N	f	f	f	\N	\N	\N	\N	\N	4	\N	\N	\N	\N	\N	\N
48	4	aide_handicap1	Allocation d’éducation de l’enfant handicapé (Aeeh)	\N	\N	f	f	f	\N	\N	\N	\N	\N	15	\N	\N	\N	\N	\N	\N
12	11	famille	Famille	\N	\N	f	f	f	\N	\N	\N	\N	\N	8	\N	\N	\N	\N	\N	\N
19	5	type_de_logement	Type de logement	\N	2	f	f	f	\N	\N	\N	\N	\N	9	\N	\N	\N	\N	\N	\N
28	7	intervenants_medicaux_internes	Intervenants médicaux internes	\N	\N	f	f	f	\N	personnel	\N	sante	\N	6	\N	\N	\N	\N	\N	\N
49	4	aide_handicap2	Allocation aux adultes handicapés (AAH)	\N	\N	f	f	f	\N	\N	\N	\N	\N	15	\N	\N	\N	\N	\N	\N
34	5	sexe	Sexe	\N	4	f	f	f	\N	\N	\N	\N	\N	4	\N	\N	\N	\N	\N	\N
24	3	notes_decision	Notes relatives à la décision de prise en charge	5	\N	t	f	f	\N	\N	\N	\N	\N	10	\N	\N	\N	\N	\N	\N
6	3	notes_prise_en_charge	Notes de prises en charges	5	\N	t	f	f	\N	\N	\N	\N	\N	5	\N	\N	\N	\N	\N	\N
41	2	date_prochain_projet	Date de prochaine mise à jour	\N	\N	f	f	f	\N	\N	\N	\N	\N	13	\N	\N	t	\N	projet	\N
40	2	date_projet	Date de dernière mise à jour	\N	\N	f	f	f	\N	\N	\N	\N	\N	13	\N	\N	t	\N	projet	\N
39	7	contact_pedagogie	Contacts enseignement et formation	\N	\N	f	f	f	\N	contact	\N	pedagogie	\N	18	\N	\N	\N	\N	\N	\N
44	3	notes_famille	Notes relatives à la famille	5	\N	t	f	f	\N	\N	\N	\N	\N	8	\N	\N	\N	\N	\N	\N
25	6	groupe_prise_en_charge	Groupe de prise en charge	\N	\N	f	f	f	prise_en_charge	\N	\N	\N	\N	5	\N	\N	\N	\N	\N	\N
36	3	projet_moyens	Moyens	5	\N	f	f	f	\N	\N	\N	\N	\N	13	\N	\N	\N	\N	\N	\N
35	3	projet_objectifs	Objectifs	5	\N	t	f	f	\N	\N	\N	\N	\N	13	\N	\N	\N	\N	\N	\N
33	3	intolerances_alimentaires	Intolérance	5	\N	t	f	f	\N	\N	\N	\N	\N	12	\N	\N	\N	\N	\N	\N
37	4	responsabilite_civile	Responsabilité civile	\N	\N	f	f	f	\N	\N	\N	\N	\N	17	\N	\N	\N	\N	\N	\N
15	1	adresse	Adresse	\N	\N	f	f	t	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N
16	1	code_postal	Code postal	\N	\N	f	f	f	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N
47	8	personnel_metier	Fonction	\N	\N	f	f	f	\N	\N	personnel	\N	\N	24	\N	\N	\N	\N	\N	\N
51	8	contact_metier	Fonction	\N	\N	f	f	f	\N	\N	contact	\N	\N	25	\N	\N	\N	\N	\N	\N
17	1	ville	Ville	\N	\N	f	f	f	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N
46	10	personnel_affectation	Affectation	\N	\N	f	f	f	\N	\N	\N	\N	\N	24	\N	\N	\N	\N	\N	\N
1	1	nom	Nom	\N	\N	f	f	f	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N
2	1	prenom	Prénom	\N	\N	f	f	f	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N
13	12	statut_usager	Statut	\N	\N	f	f	f	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N
52	1	telephone_fixe	Téléphone fixe	\N	\N	f	f	f	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N
53	1	telephone_mobile	Téléphone mobile	\N	\N	f	f	f	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N
3	2	date_naissance	Date de naissance	\N	\N	f	f	f	\N	\N	\N	\N	\N	3	\N	\N	f	\N	\N	\N
\.


--
-- Data for Name: info_aide; Type: TABLE DATA; Schema: meta; Owner: variation
--

COPY info_aide (ina_id, inf_id, ina_aide) FROM stdin;
3	15	Ce champ est un champ multiple. Il pourra contenir plusieurs lignes.
5	43	Ce champ est un exemple de validation de l'existence d'une pièces necessaire à l'admission d'une usager.\n\nLe document correspondant pourra etre numérisé et déposé dans l'espace "documents" si nécessaire.
4	42	Ce champ est un exemple de validation de l'existence d'une autorisation.\n\nLe document correspondant pourra etre numérisé et déposé dans l'espace "documents" si nécessaire.
2	46	Permet d'affecter un membre du personnel à un groupe de l'établissement. \n\nAttention! Ce champs n'est pas associé à une quelconque gestion de droit d'accès pour l'utilisateur. \n\nCe champs ne peut etre utilisé que dans les masques et listes de membres du personnel.
1	47	Permet d'associer un membre du personnel à une fonction. La fonction sera utilisée pour filtrer les employées dans les boitier de sélection des champs de type "lien".\n\nCe champ est réservé aux listes d'employés et aux masques de saisie relatifs aux employés.\n\nCe champs ne peut etre utilisé que dans les masques et listes de membres du personnel.
8	12	Ce champ est un exemple de definition de liens avec des membres familiaux.
9	20	Ce champ est un exemple de boitier de sélection.\n\nIl peut etre à priori aussi bien utilisé pour les données des usagers que celles des familles.
15	27	Ce champ est un exemple de champ de type lien entre usager et contact. Il cible les contacts dont le métier relève de le thématique de décision de prise en charge.
14	34	Ce champ est un exemple de champ de type "boitier de sélection".\n\nIl peut etre utilisé aussi bien pour les usager que pour les membres familiaux, les membres du personnel ou les contacts.
25	38	Ce champ est un exemple de champ de type "texte".\n\nIl peut etre utilisé aussi bien pour les usager que pour les membres familiaux.
21	24	Ce champ est un exemple de champ texte libre.\n\nL'option "étendu" permet un affichage sur toute la largeur du masque de saisie. \n\nCe champ peut etre intégré dans une vue de liste ou dans un masque de saisie.
18	41	Ce champ est un exemple de champ de type "date".\n\nL'option "échéance" permet de faire apparaitre cette date dans les agendas.
19	40	Ce champ est un exemple de champ de type "date".\n\nL'option "échéance" permet de faire apparaitre cette date dans les agendas.
20	25	Ce champ est un exemple de champ de type "affectation". Il permettra d'affecter un usager à des modalités de prise en charge.\n\nAu moins un champ de type "affectation" ciblant la thématique "prise en charge" est nécessaire au bon fonctionnement de l'application.
26	22	Ce champ est un exemple de champ de type "texte".\n\nIl est à priori seulement utilisé pour les usagers.
27	23	Ce champ est un exemple de champ de type "texte".\n\nIl est à priori seulement utilisé pour les usagers.
13	26	Ce champ est un exemple de champ de type "texte".\n\nIl peut etre utilisé aussi bien pour les usagers que pour les membres familiaux ou les membres du personnel.
12	4	Ce champ est un exemple de champ de type "texte".\n\nIl peut etre utilisé aussi bien pour les usagers que pour les membres familiaux ou les membres du personnel.
28	19	Ce champ est un exemple de champ de type "boitier de sélection".
29	16	Ce champ est un exemple de champ de type "texte".\n\nIl peut etre utilisé aussi bien pour les usagers que pour les membres familiaux, les membres du personnel ou les contacts.
30	17	Ce champ est un exemple de champ de type "texte".\n\nIl peut etre utilisé aussi bien pour les usagers que pour les membres familiaux, les membres du personnel ou les contacts.
23	35	Ce champ est un exemple de champ texte libre.\n\nL'option "étendu" permet un affichage sur toute la largeur du masque de saisie. \n\nCe champ peut etre intégré dans une vue de liste ou dans un masque de saisie.
6	6	Ce champ est un exemple de champ texte libre.\n\nL'option "étendu" permet un affichage sur toute la largeur du masque de saisie. \n\nCe champ peut etre intégré dans une vue de liste ou dans un masque de saisie.
10	44	Ce champ est un exemple de champ texte libre.\n\nL'option "étendu" permet un affichage sur toute la largeur du masque de saisie. \n\nCe champ peut etre intégré dans une vue de liste ou dans un masque de saisie.
22	36	Ce champ est un exemple de champ texte libre.\n\nL'option "étendu" permet un affichage sur toute la largeur du masque de saisie. \n\nCe champ peut etre intégré dans une vue de liste ou dans un masque de saisie.
24	33	Ce champ est un exemple de champ texte libre.\n\nL'option "étendu" permet un affichage sur toute la largeur du masque de saisie. \n\nCe champ peut etre intégré dans une vue de liste ou dans un masque de saisie.
31	37	Ce champ est un exemple de champ de type "case à cocher".
32	30	Ce champ est un exemple de champ de type "case à cocher".
33	48	Ce champ est un exemple de champ de type "case à cocher".
34	49	Ce champ est un exemple de champ de type "case à cocher".
16	1	Ce champ est indispensable au fonctionnement de l'application.\n\nIl doit etre utilisé aussi bien pour les usager que pour les membres familiaux, les contacts ou les membres du personnel.
17	2	Ce champ est indispensable au fonctionnement de l'application.\n\nIl doit etre utilisé aussi bien pour les usager que pour les membres familiaux, les contacts ou les membres du personnel.
7	13	Ce champ est indispensable au fonctionnement de l'application.\n\nLa valeur de ce champ est calculé automatiquement pour chaque usager à partir des prises en charge.\n\nCe champ ne peut etre utilisé que dans les masques et listes d'usagers.
35	52	Ce champ est indispensable au fonctionnement de l'application.\n\nIl doit etre utilisé aussi bien pour les membres familiaux, les contacts ou les membres du personnel.\n\nIl peut etre utilisé pour les usagers.\n
36	53	Ce champ est indispensable au fonctionnement de l'application.\n\nIl doit etre utilisé aussi bien pour les membres familiaux, les contacts ou les membres du personnel.\n\nIl peut etre utilisé pour les usagers.
11	3	Ce champ est un exemple de champ de type "date".\n\nCe champ est indispensable au fonctionnement de l'application.\n\nIl doit etre utilisé pour les usagers.\n\nIl peut etre utilisé pour les membres familiaux, les contacts externes ou les membres du personnel.\n\n\n
\.


--
-- Name: info_aide_ina_id_seq; Type: SEQUENCE SET; Schema: meta; Owner: variation
--

SELECT pg_catalog.setval('info_aide_ina_id_seq', 36, true);


--
-- Name: info_inf_id_seq; Type: SEQUENCE SET; Schema: meta; Owner: variation
--

SELECT pg_catalog.setval('info_inf_id_seq', 53, true);


--
-- Data for Name: infos_type; Type: TABLE DATA; Schema: meta; Owner: variation
--

COPY infos_type (int_id, int_code, int_libelle, int_multiple, int_historique) FROM stdin;
9	etablissement	Affectation à organisme	t	t
11	famille	Famille	t	f
1	texte	Champ texte	t	t
2	date	Champ date	t	t
3	textelong	Texte multi-ligne	f	f
4	coche	Case à cocher	f	t
5	selection	Boîtier de sélection	t	t
6	groupe	Affectation d'usager	f	f
7	contact	Lien	t	t
8	metier	Métier	t	t
10	affectation	Affectation de personnel	t	f
12	statut_usager	Statut d'usager	f	f
\.


--
-- Name: infos_type_int_id_seq; Type: SEQUENCE SET; Schema: meta; Owner: variation
--

SELECT pg_catalog.setval('infos_type_int_id_seq', 12, true);


--
-- Data for Name: secteur; Type: TABLE DATA; Schema: meta; Owner: variation
--
COPY secteur (sec_id, sec_code, sec_nom, sec_est_prise_en_charge, sec_icone) FROM stdin;
22	protection_juridique	Protection juridique	f	/Images/IS_real_vista_security/png/NORMAL/%d/protection_%d.png
29	projet	Projet individuel	f	/Images/IS_Real_vista_Medical/originals/png/NORMAL/%d/prescription_%d.png
27	equipement_personnel	Vêture et autres fournitures	f	/Images/IS_Real_vista_Education_icons/originals/png/NORMAL/%d/backpack_%d.png
1	social	Socialisation	f	/Images/IS_Real_vista_Social/originals/png/NORMAL/%d/mutual_friends_%d.png
21	divertissement	Activités de divertissement	f	/Images/IS_Real_vista_Electrical_appliances/originals/png/NORMAL/%d/television_%d.png
2	education	Suivi éducatif	f	/Images/IS_Real_vista_Social/originals/png/NORMAL/%d/follow_%d.png
6	emploi	Stages, apprentissage et emploi	f	/Images/IS_real_vista_transportation/png/NORMAL/%d/Motor_mechanic_%d.png
28	famille	Famille et relations personnelles	f	/Images/IS_Real_vista_Education_icons/originals/png/NORMAL/%d/parent_coordinator_%d.png
19	financeur	Financement de prise en charge	t	/Images/IS_real_vista_project_managment/png/NORMAL/%d/budget_%d.png
26	aide_financiere_directe	Aides financières / allocations / ressources	t	/Images/IS_Real_vista_Accounting/originals/png/NORMAL/%d/withdrawal_%d.png
30	sejour	Séjours et excursions	f	/Images/IS_real_vista_real_state/png/NORMAL/%d/rest_area_%d.png
9	culture	Activités culturelles	f	/Images/IS_real_vista_real_state/png/NORMAL/%d/museum_%d.png
3	sante	Suivi médical	f	/Images/IS_Real_vista_Medical/originals/png/NORMAL/%d/first_aid_kit_%d.png
61	soins_infirmiers	Soins infirmiers	f	/Images/IS_Real_vista_Medical/originals/png/NORMAL/%d/nurse_%d.png
63	ergotherapie	Ergothérapie	f	/Images/IS_Real_vista_Medical/originals/png/NORMAL/%d/occupational_therapy_%d.png
64	physiotherapie	Physiothérapie	f	/Images/IS_real_vista_sports/originals/png/NORMAL/%d/floor_gymnastics_%d.png
65	kinesitherapie	Kinésithérapie	f	/Images/IS_Real_vista_3d_graphics/originals/png/NORMAL/%d/figure_%d.png
66	orthophonie	Orthophonie	f	/Images/IS_Real_vista_Communications/originals/png/NORMAL/%d/kiss_%d.png
67	psychomotricite	Psychomotricité	f	/Images/IS_real_vista_sports/originals/png/NORMAL/%d/balance_beam_%d.png
68	psychologie	Psychologie	f	/Images/IS_Real_vista_Medical/originals/png/NORMAL/%d/ophthalmology_%d.png
69	droits_de_sejour	Droits de séjour	f	/Images/IS_Real_vista_Flags/originals/png/NORMAL/%d/France_%d.png
70	aide_formalites	Aide aux formalités administratives	f	/Images/IS_Real_vista_Accounting/originals/png/NORMAL/%d/stamp_%d.png
24	entretien	Tâches collectives / entretien	f	/Images/IS_Real_vista_Electrical_appliances/originals/png/NORMAL/%d/vacuum_cleaner_%d.png
4	pedagogie	Scolarité / formation / réinsertion	f	/Images/IS_real_vista_real_state/png/NORMAL/%d/class_room_%d.png
25	aide_a_la_personne	Hygiène corporelle / aide à la personne	f	/Images/IS_Real_vista_Social/originals/png/NORMAL/%d/join_%d.png
62	dietetique	Accompagnement diététique	f	/Images/IS_Real_vista_Food/originals/png/NORMAL/%d/apples_%d.png
7	hebergement	Logement et equipement	f	/Images/IS_real_vista_real_state/png/NORMAL/%d/bedroom_%d.png
23	restauration	Restauration / alimentation	f	/Images/IS_Real_vista_Social/originals/png/NORMAL/%d/cuisines_%d.png
20	prise_en_charge	Admission et prise en charge	t	/Images/IS_Real_vista_Development/originals/png/NORMAL/%d/float_%d.png
11	decideur	Décision / orientation / mesure	t	/Images/IS_real_vista_project_managment/png/NORMAL/%d/legal_issues_%d.png
10	transport	Transport / déplacements	f	/Images/IS_Real_vista_Education_icons/originals/png/NORMAL/%d/transportation_service_%d.png
8	sport	Activités sportives	f	/Images/IS_real_vista_sports/originals/png/NORMAL/%d/marathon_%d.png
5	justice	Procédures judiciaires / incarcération	f	/Images/IS_Real_vista_Accounting/originals/png/NORMAL/%d/balance_%d.png
\.


--
-- Name: secteur_sec_id_seq; Type: SEQUENCE SET; Schema: meta; Owner: variation
--

SELECT pg_catalog.setval('secteur_sec_id_seq', 30, true);


--
-- Data for Name: selection; Type: TABLE DATA; Schema: meta; Owner: variation
--

COPY selection (sel_id, sel_code, sel_libelle, sel_info) FROM stdin;
1	problematique	Problematique	\N
2	type_de_logement	Type de logement	\N
3	composition_famille	Composition de famille	\N
4	sexe	Sexe	\N
5	animal_de_compagnie	Animal de compagnie	\N
\.


--
-- Data for Name: selection_entree; Type: TABLE DATA; Schema: meta; Owner: variation
--

COPY selection_entree (sen_id, sel_id, sen_libelle, sen_ordre) FROM stdin;
1	1	Carence éducative	1
2	1	Difficultés financières	2
3	2	Studio	1
4	2	T2	2
5	3	Monoparentale	1
6	3	Couple	2
7	3	Couple recomposé	3
8	3	Autre	4
9	4	M	1
10	4	F	2
11	5	Chien	1
12	5	Chat	2
\.


--
-- Name: selection_entree_sen_id_seq; Type: SEQUENCE SET; Schema: meta; Owner: variation
--

SELECT pg_catalog.setval('selection_entree_sen_id_seq', 12, true);


--
-- Name: selection_sel_id_seq; Type: SEQUENCE SET; Schema: meta; Owner: variation
--

SELECT pg_catalog.setval('selection_sel_id_seq', 5, true);


--
-- Name: dirinfo_pkey; Type: CONSTRAINT; Schema: meta; Owner: variation; Tablespace: 
--

ALTER TABLE ONLY dirinfo
    ADD CONSTRAINT dirinfo_pkey PRIMARY KEY (din_id);


--
-- Name: entite_ent_code_unique; Type: CONSTRAINT; Schema: meta; Owner: variation; Tablespace: 
--

ALTER TABLE ONLY entite
    ADD CONSTRAINT entite_ent_code_unique UNIQUE (ent_code);


--
-- Name: entite_pkey; Type: CONSTRAINT; Schema: meta; Owner: variation; Tablespace: 
--

ALTER TABLE ONLY entite
    ADD CONSTRAINT entite_pkey PRIMARY KEY (ent_id);


--
-- Name: info_aide_pkey; Type: CONSTRAINT; Schema: meta; Owner: variation; Tablespace: 
--

ALTER TABLE ONLY info_aide
    ADD CONSTRAINT info_aide_pkey PRIMARY KEY (ina_id);


--
-- Name: info_inf_code_unique; Type: CONSTRAINT; Schema: meta; Owner: variation; Tablespace: 
--

ALTER TABLE ONLY info
    ADD CONSTRAINT info_inf_code_unique UNIQUE (inf_code);


--
-- Name: info_pkey; Type: CONSTRAINT; Schema: meta; Owner: variation; Tablespace: 
--

ALTER TABLE ONLY info
    ADD CONSTRAINT info_pkey PRIMARY KEY (inf_id);


--
-- Name: infos_type_pkey; Type: CONSTRAINT; Schema: meta; Owner: variation; Tablespace: 
--

ALTER TABLE ONLY infos_type
    ADD CONSTRAINT infos_type_pkey PRIMARY KEY (int_id);


--
-- Name: secteur_pkey; Type: CONSTRAINT; Schema: meta; Owner: variation; Tablespace: 
--

ALTER TABLE ONLY secteur
    ADD CONSTRAINT secteur_pkey PRIMARY KEY (sec_id);


--
-- Name: secteur_sec_code_key; Type: CONSTRAINT; Schema: meta; Owner: variation; Tablespace: 
--

ALTER TABLE ONLY secteur
    ADD CONSTRAINT secteur_sec_code_key UNIQUE (sec_code);


--
-- Name: selection_entree_pkey; Type: CONSTRAINT; Schema: meta; Owner: variation; Tablespace: 
--

ALTER TABLE ONLY selection_entree
    ADD CONSTRAINT selection_entree_pkey PRIMARY KEY (sen_id);


--
-- Name: selection_pkey; Type: CONSTRAINT; Schema: meta; Owner: variation; Tablespace: 
--

ALTER TABLE ONLY selection
    ADD CONSTRAINT selection_pkey PRIMARY KEY (sel_id);


--
-- Name: selection_sel_code_unique; Type: CONSTRAINT; Schema: meta; Owner: variation; Tablespace: 
--

ALTER TABLE ONLY selection
    ADD CONSTRAINT selection_sel_code_unique UNIQUE (sel_code);


--
-- Name: fki_dirinfo_din_id_parent_fkey; Type: INDEX; Schema: meta; Owner: variation; Tablespace: 
--

CREATE INDEX fki_dirinfo_din_id_parent_fkey ON dirinfo USING btree (din_id_parent);


--
-- Name: fki_info_aide_inf_id_fkey; Type: INDEX; Schema: meta; Owner: variation; Tablespace: 
--

CREATE INDEX fki_info_aide_inf_id_fkey ON info_aide USING btree (inf_id);


--
-- Name: fki_info_din_id_fkey; Type: INDEX; Schema: meta; Owner: variation; Tablespace: 
--

CREATE INDEX fki_info_din_id_fkey ON info USING btree (din_id);


--
-- Name: fki_info_inf__date_echeance_secteur_fkey; Type: INDEX; Schema: meta; Owner: variation; Tablespace: 
--

CREATE INDEX fki_info_inf__date_echeance_secteur_fkey ON info USING btree (inf__date_echeance_secteur);


--
-- Name: fki_info_inf__etablissement_secteur_fkey; Type: INDEX; Schema: meta; Owner: variation; Tablespace: 
--

CREATE INDEX fki_info_inf__etablissement_secteur_fkey ON info USING btree (inf__etablissement_secteur);


--
-- Name: fki_info_inf__selection_code_fkey; Type: INDEX; Schema: meta; Owner: variation; Tablespace: 
--

CREATE INDEX fki_info_inf__selection_code_fkey ON info USING btree (inf__selection_code);


--
-- Name: info_inf_code_idx; Type: INDEX; Schema: meta; Owner: variation; Tablespace: 
--

CREATE INDEX info_inf_code_idx ON info USING btree (inf_code);


--
-- Name: dirinfo_din_id_parent_fkey; Type: FK CONSTRAINT; Schema: meta; Owner: variation
--

ALTER TABLE ONLY dirinfo
    ADD CONSTRAINT dirinfo_din_id_parent_fkey FOREIGN KEY (din_id_parent) REFERENCES dirinfo(din_id);


--
-- Name: info_aide_inf_id_fkey; Type: FK CONSTRAINT; Schema: meta; Owner: variation
--

ALTER TABLE ONLY info_aide
    ADD CONSTRAINT info_aide_inf_id_fkey FOREIGN KEY (inf_id) REFERENCES info(inf_id);


--
-- Name: info_din_id_fkey; Type: FK CONSTRAINT; Schema: meta; Owner: variation
--

ALTER TABLE ONLY info
    ADD CONSTRAINT info_din_id_fkey FOREIGN KEY (din_id) REFERENCES dirinfo(din_id);


--
-- Name: info_inf__date_echeance_secteur_fkey; Type: FK CONSTRAINT; Schema: meta; Owner: variation
--

ALTER TABLE ONLY info
    ADD CONSTRAINT info_inf__date_echeance_secteur_fkey FOREIGN KEY (inf__date_echeance_secteur) REFERENCES secteur(sec_code);


--
-- Name: info_inf__etablissement_secteur_fkey; Type: FK CONSTRAINT; Schema: meta; Owner: variation
--

ALTER TABLE ONLY info
    ADD CONSTRAINT info_inf__etablissement_secteur_fkey FOREIGN KEY (inf__etablissement_secteur) REFERENCES secteur(sec_code);


--
-- Name: info_inf__selection_code_fkey; Type: FK CONSTRAINT; Schema: meta; Owner: variation
--

ALTER TABLE ONLY info
    ADD CONSTRAINT info_inf__selection_code_fkey FOREIGN KEY (inf__selection_code) REFERENCES selection(sel_id) DEFERRABLE;


--
-- Name: info_int_id_fkey; Type: FK CONSTRAINT; Schema: meta; Owner: variation
--

ALTER TABLE ONLY info
    ADD CONSTRAINT info_int_id_fkey FOREIGN KEY (int_id) REFERENCES infos_type(int_id);


--
-- Name: selection_entree_sel_id_fkey; Type: FK CONSTRAINT; Schema: meta; Owner: variation
--

ALTER TABLE ONLY selection_entree
    ADD CONSTRAINT selection_entree_sel_id_fkey FOREIGN KEY (sel_id) REFERENCES selection(sel_id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

